#!/bin/bash
dot="$(cd "$(dirname "$0")"; pwd)"
Rscript -e "setwd('"$dot"');library(shinyMixR);run_shinymixr(launch.browser=TRUE)"
