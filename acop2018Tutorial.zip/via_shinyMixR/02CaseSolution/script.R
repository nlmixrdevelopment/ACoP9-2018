library(shinyMixR)
run_shinymixr(launch.browser=TRUE)

# Adapt dataset to calculate the log of weights
# dat        <- readRDS("data/theo_sd.rds")
# dat$lnWT70 <- log(dat$WT/70)
# saveRDS(dat,"data/theo_sd_lnw.rds")
