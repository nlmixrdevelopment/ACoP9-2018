# Make sure the working directory is set to the location of this script.
# This can be done using Rstudio --> session --> set working directory --> To source file location
# It is alos possible to use setwd()
library(shinyMixR)
run_shinymixr(launch.browser=TRUE)
